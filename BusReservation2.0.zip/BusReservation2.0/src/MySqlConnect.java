/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.sql.*;
import javax.swing.*;


/**
 *
 * @author Natezhiel
 */
public class MySqlConnect {
    Connection conn=null;
    public static Connection ConnectionDB(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn=DriverManager.getConnection("jdbc:mysql://localhost/busreservationdb", "root", "");
            return conn;
        }
     catch (Exception e){
    JOptionPane.showMessageDialog(null, e);
    return null;
    }

    }
    
}